# RunwayHub v1.0.0 - Release

**Release Date:** 2026-05-28  
**Version:** 1.0.0 (Initial Release)

---

## 🎉 Willkommen zu RunwayHub

Das erste Release von RunwayHub - ein komplettes Virtual Airline Management System für Flugsimulation.

---

## ✨ Highlights

- ✅ Multi-Airline Support
- ✅ Live-Flugverfolgung (FlightAware)
- ✅ Wetter-API Integration (METAR/TAF)
- ✅ VA Management (Erstellen/Verbinden)
- ✅ Login System (Callsign/Passwort)
- ✅ ACARS Client (Simulation)
- ✅ Modernes Design mit Flight Board

---

## 🚀 Installation

### 1. Unzip

```bash
tar -xzf runwayhub-v1.0.0.tar.gz
cd runwayhub
```

### 2. Dependencies installieren

```bash
composer install
```

### 3. Server starten

```bash
php -S localhost:8000 -t public
```

### 4. Browser öffnen

```
http://localhost:8000
```

---

## 🔐 Demo Accounts

| Callsign | Passwort | Rolle |
|----------|----------|---------|
| demo_admin | admin123 | Admin |
| demo_pilot | pilot123 | Pilot |
| demo_guest | guest123 | Guest |

---

## 📚 Dokumentation

- [Setup Guide](SETUP.md)
- [API Endpoints](README.md)
- [Architecture](docs/architecture.md)
- [Database](docs/database.md)
- [Weather API](docs/weather-api.md)
- [FlightAware](docs/flightaware.md)

---

## 🔧 API Endpoints

### Login
```bash
POST /api/login-pilot.php
Content-Type: application/json

{
  "callsign": "demo_pilot",
  "password": "pilot123"
}
```

### VA Erstellen
```bash
POST /api/va-create.php
Content-Type: application/json

{
  "name": "Deutsche Airline",
  "airlineName": "Deutsche Airline",
  "website": "https://www.deutsche-airline.de",
  "logo": "logo.png",
  "colors": {
    "primary": "#000000",
    "secondary": "#ffffff"
  }
}
```

### VA Verbinden
```bash
POST /api/va-connect.php
Content-Type: application/json

{
  "ownerCredentials": {
    "username": "user123",
    "password": "***"
  },
  "website": "https://www.deutsche-airline.de"
}
```

---

## 🛠️ System Requirements

- **PHP:** 8.3+
- **Database:** SQLite oder MySQL
- **Extensions:** PDO, curl
- **RAM:** 256MB+

---

## 🔒 Sicherheit

- bcrypt Passwörter (cost=12)
- HttpOnly, Secure, SameSite Cookies
- SQL Injection Schutz
- XSS Schutz

---

## 🐛 Bekannte Issues

- ACARS benötigt echten MQTT-Broker (Simulation im Demo)
- SQLite-PDO-Connector optional

---

## 📝 Changelog

Siehe [CHANGELOG.md](CHANGELOG.md) für detaillierte Änderungen.

---

## 🤝 Support

- GitHub Issues
- Documentation
- Community Forum

---

**Built with ❤️ by @chris1971nrw**

**Licensed under MIT**
